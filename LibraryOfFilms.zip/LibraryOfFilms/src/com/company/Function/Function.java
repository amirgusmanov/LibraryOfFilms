package com.company.Function;

/**
 * Interface that describing behavior of all functions {@link com.company.CallFunctions}
 * @author Amir Gusmanov
 */
public interface Function {

    void function();

}
