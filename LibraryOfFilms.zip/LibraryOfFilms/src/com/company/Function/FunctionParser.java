package com.company.Function;

/**
 * Interface that describing behavior of {@link FunctionGenerator}
 * @author Amir Gusmanov
 */
public interface FunctionParser {

    Function command(String type);

}
